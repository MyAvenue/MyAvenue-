/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Backend;

import java.util.ArrayList;
import java.util.Date;

public class Student extends User {

    public Student(String zID, String name, String password, String email, String phoneNumber, String gender, String userClass) {
        super(zID, name, password, email, phoneNumber, gender, userClass);
        this.gender= gender;
        this.userClass= userClass;
    }
    public void setGender(String gender) {
    	this.gender= gender;
	}
    public void setUserClass(String userClass) {
    	this.userClass= userClass;
	}
    
    
    public String getType() {
        return "Student";
    }
}
