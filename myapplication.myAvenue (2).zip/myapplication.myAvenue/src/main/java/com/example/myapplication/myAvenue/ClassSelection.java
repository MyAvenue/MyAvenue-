package com.example.myapplication.myAvenue;


import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.ui.*;
import Backend.MainSystem;

public class ClassSelection extends VerticalLayout implements View {
	MainSystem main = new MainSystem(); //link to backend

	public ClassSelection(){

		Button btnArchitect;
		Button btnBuinessAnalyst;
		Button btnConsultant;
		Button btnDesigner;
		Button btnDeveloper;
		Button btnProjectManager;

		//Add horizontal layout for buttons
		HorizontalLayout HLayout = new HorizontalLayout();

		btnArchitect = new Button("Architect");
		btnArchitect.addStyleName("primary");
		//Navigation
		btnArchitect.addClickListener(new Button.ClickListener() {
			@Override
			public void buttonClick(Button.ClickEvent event) {
				main.getCurrentUser().setUserClass("Architect");
				getUI().getNavigator().navigateTo("dashboard");

			}
		});
		btnBuinessAnalyst = new Button("BuinessAnalyst");
		btnBuinessAnalyst.addStyleName("friendly");
		//Navigation
		btnBuinessAnalyst.addClickListener(new Button.ClickListener() {
			@Override
			public void buttonClick(Button.ClickEvent event) {
				main.getCurrentUser().setUserClass("Business Analyst");
				
				getUI().getNavigator().navigateTo("dashboard");

			}
		});
		btnConsultant = new Button("Consultant");
		btnConsultant.addStyleName("primary");
		//Navigation
		btnConsultant.addClickListener(new Button.ClickListener() {
			@Override
			public void buttonClick(Button.ClickEvent event) {
				main.getCurrentUser().setUserClass("Consultant");
				
				getUI().getNavigator().navigateTo("dashboard");

			}
		});
		btnDeveloper = new Button("Developer");
		btnDeveloper.addStyleName("primary");
		//Navigation
		btnDeveloper.addClickListener(new Button.ClickListener() {
			@Override
			public void buttonClick(Button.ClickEvent event) {
				main.getCurrentUser().setUserClass("Developer");
				
				
				getUI().getNavigator().navigateTo("dashboard");

			}
		});
		btnDesigner = new Button("Designer");
		btnDesigner.addStyleName("friendly");
		//Navigation
		btnDesigner.addClickListener(new Button.ClickListener() {
			@Override
			public void buttonClick(Button.ClickEvent event) {
				main.getCurrentUser().setUserClass("Designer");
						
				getUI().getNavigator().navigateTo("dashboard");

			}
		});
		btnProjectManager = new Button("Project Manager");
		btnProjectManager.addStyleName("friendly");
		//Navigation
		btnProjectManager.addClickListener(new Button.ClickListener() {
			@Override
			public void buttonClick(Button.ClickEvent event) {
				main.getCurrentUser().setUserClass("Project Manager");
				
				getUI().getNavigator().navigateTo("dashboard");

			}
		});

		HLayout.addComponent(btnArchitect);
		HLayout.addComponent(btnBuinessAnalyst);
		HLayout.addComponent(btnConsultant);
		HLayout.addComponent(btnDesigner);
		HLayout.addComponent(btnDeveloper);
		HLayout.addComponent(btnProjectManager);
		HLayout.setSpacing(true);

		//Form Layout
		FormLayout formLayout = new FormLayout(HLayout);
		formLayout.setMargin(true);

		//Panel
		Panel loginPanel = new Panel("Step 2: Pick Your Class", formLayout);
		loginPanel.setWidth("1000");
		loginPanel.setHeight("250");


		//Add Components
		addComponent(loginPanel);
		setComponentAlignment(loginPanel, Alignment.MIDDLE_CENTER);
		setHeight("100%");

	}

	@Override
	public void enter(ViewChangeListener.ViewChangeEvent event) {

	}
}
