package com.example.myapplication.myAvenue;

import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;


import com.vaadin.ui.*;
import Backend.MainSystem;
import Backend.User;

public class GenderSelection extends VerticalLayout implements View {
	MainSystem main = new MainSystem(); //link to backend
	public GenderSelection(){

		Button btnMale;
		Button btnFemale;

		//Add horizontal layout for buttons
		HorizontalLayout HLayout = new HorizontalLayout();

		btnMale = new Button("Male");
		btnMale.addStyleName("primary");
		//Navigation
		btnMale.addClickListener(new Button.ClickListener() {
			@Override
			public void buttonClick(Button.ClickEvent event) {
				main.getCurrentUser().setGender("Male");
		            
				getUI().getNavigator().navigateTo("ClassSelection");

			}
		});
		btnFemale = new Button("Female");
		btnFemale.addStyleName("friendly");
		//Navigation
		btnFemale.addClickListener(new Button.ClickListener() {
			@Override
			public void buttonClick(Button.ClickEvent event) {
				main.getCurrentUser().setGender("Female");
				
				getUI().getNavigator().navigateTo("ClassSelection");

			}
		});
		HLayout.addComponent(btnMale);
		HLayout.addComponent(btnFemale);
		HLayout.setSpacing(true);

		//Form Layout
		FormLayout formLayout = new FormLayout(HLayout);
		formLayout.setMargin(true);

		//Panel
		Panel loginPanel = new Panel("Step 1: Select Your Gender", formLayout);
		loginPanel.setWidth("450");
		loginPanel.setHeight("250");


		//Add Components
		addComponent(loginPanel);
		setComponentAlignment(loginPanel, Alignment.MIDDLE_CENTER);
		setHeight("100%");

	}

	@Override
	public void enter(ViewChangeListener.ViewChangeEvent event) {

	}
}
